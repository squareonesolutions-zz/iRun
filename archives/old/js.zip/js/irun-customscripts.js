
		$(document).ready(function() {
			/*
			*   Examples - images
			*/

			$("a#openingVideo").fancybox({
				'titlePosition'		: 'outside',
				'overlayColor'		: '#000',
				'overlayOpacity'	: 1.0,
				'transitionIn'		: 'elastic',
				'transitionOut'		: 'none',
				'padding'			: 20,
				'autoScale'			: false,
				'overlayShow'		: true
			});
			
			
			$("a#mediaPopup").fancybox({
				'titlePosition'		: 'intside',
				'overlayColor'		: '#000',
				'overlayOpacity'	: 0.5,
				'transitionIn'		: 'elastic',
				'transitionOut'		: 'elastic',
				'padding'			: 15,
				'autoScale'			: true,
				'overlayShow'		: true
			});
			
		});
	